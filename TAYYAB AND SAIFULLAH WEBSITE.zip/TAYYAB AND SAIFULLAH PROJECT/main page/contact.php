<?php
    $host="localhost";
    $Username="root";
    $Password="";
    $database="gymz";
    $con= mysqli_connect($host,$Username,$Password,$database);
    if(!$con)
    {
        die ("error detected". mysqli_connect($con));
    }
    else {
        echo "Successfull";
    
    if(isset($_POST['apply']))
    {
    
            $data_name=$_POST['name'];
            $data_email=$_POST['email'];
            $data_message=$_POST['password'];
        
        $sql="insert into contact(name,email,password)
        values('$data_name','$data_email','$data_message');";
    $result=mysqli_query($con,$sql);
    if($result)
    {
    echo "<script>alert('new record inserted'); <script>";
    }
    else
    {
        echo "apply failed". mysqli_error($conn);;
    }
    mysqli_close($conn);
    }
    }
   
?>

