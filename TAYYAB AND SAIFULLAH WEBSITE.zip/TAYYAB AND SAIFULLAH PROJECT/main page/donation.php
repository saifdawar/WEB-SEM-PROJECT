<?php
$host="localhost";
    $Username="root";
    $Password="";
    $database="gymz";
    $conn= mysqli_connect($host,$Username,$Password,$database);
    if(!$conn)
    {
        die ("error detected". mysqli_connect($conn));
    }
    else {
        echo "Successfull";
    
    if(isset($_POST['submit']))
    {
    
            $data_name=$_POST['name'];
            $data_phone=$_POST['phone'];
            $data_address=$_POST['address'];

            $data_country=$_POST['country'];
            $data_email=$_POST['email'];
        $sql="insert into donation(name,phone,address,country,email)
        values('$data_name','$data_phone','$data_address','$data_country','$data_email')";
    $result=mysqli_query($conn,$sql);
    if($result)
    {
    echo "<script>alert('new record inserted'); <script>";
    }
    else
    {
        echo "apply failed". mysqli_error($conn);;
    }
    mysqli_close($conn);
    }
    }
    ?>